//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Zjw002.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_ZJW002TYPE                  129
#define IDD_DIALOG1                     130
#define ID_GRAY                         32771
#define ID_Histogram                    32772
#define ID_LINETRANS                    32773
#define ID_EQUALIZE                     32774
#define ID_FT                           32775
#define ID_IFT                          32776
#define ID_FFT                          32777
#define ID_IFFT                         32778
#define ID_MED_FILETER                  32779
#define ID_GRAD_SHARP                   32780
#define ID_AVG_FILTER                   32781
#define ID_RAPLAS_SHARP                 32782
#define ID_FFT_FILTER                   32783
#define ID_ILP_FILTER                   32784
#define ID_GLP_FILTER                   32785

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32786
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
