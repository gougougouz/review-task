_declspec (dllexport) int add(int a, int b)
{
	return a + b;
}
_declspec (dllexport) int subtract(int a, int b)
{
	return a - b;
}

