//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by test1.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_TEST1TYPE                   129
#define IDB_BITMAP1                     130
#define IDB_BITMAP2                     133
#define IDB_BITMAP3                     134
#define IDR_MENU1                       135
#define IDD_DIALOG1                     136
#define IDD_DIALOG2                     137
#define IDR_TOOLBAR1                    140
#define IDC_BTN_ADD                     1000
#define IDC_EDIT1                       1002
#define IDC_EDIT2                       1003
#define IDC_EDIT3                       1004
#define IDC_NUMBER1                     1005
#define IDC_NUMBER2                     1006
#define IDC_NUMBER3                     1007
#define IDC_BUTTON1                     1008
#define IDC_SEPARATOR                   1009
#define IDC_BUTTON2                     1010
#define IDC_BTN_DLLADD                  1011
#define IDC_BTN_DLLSUBTRAC              1012
#define IDM_MYMENU                      32771
#define IDM_SHOW                        32772
#define IDM_EXIT                        32773
#define IDM_DILOG                       32774
#define IDM_DLG2                        32775
#define IDM_VIEW_NEWTOOL                32779
#define IDS_ZHAOJUNWEN                  61446
#define IDS_TIMER                       61447
#define IDS_PROGRESS                    61448

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
